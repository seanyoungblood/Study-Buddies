const asyncHandler = require('express-async-handler')

const Class = require('../models/classModel')

const getUser = asyncHandler(async (req, res) => {
    const classes = await Class.find()
    res.status(200).json(classes)
})

const setUser = asyncHandler(async (req, res) => {
    if (!req.body.text)
    {
        res.status(400)
        throw new Error('Please add a text field')
    }
    const classes = await Class.create({
        text: req.body.text
    })

    res.status(200).json(classes)
})

const updateUser = asyncHandler(async (req, res) => {
    const classes = await Class.findById(req.params.id)

    if (!classes){
        res.status(400)
        throw new Error('Class not found')
    }

    const updatedClass = await Class.findByIdAndUpdate(req.params.id, req.body, { new: true,})

    res.status(200).json(updatedClass)
})

const deleteUser = asyncHandler(async (req, res) => {

    const classes = await Class.findById(req.params.id)

    if (!classes){
        res.status(200)
        throw new Error('Class doesn not exist to delete')
    }

    await classes.remove()
    res.status(200).json({id: req.params.id})

    /*
    const classes = await Class.findById(req.params.id)

    if (!classes){
        res.status(200)
        throw new Error('Class doesn not exist to delete')
    }

    const deletedClass = await Class.findByIdAndDelete(req.params.id, req.body)

    res.status(200).json(`Class Deleted: ${deletedClass}`)
    */
})


module.exports = {
    getUser,
    setUser,
    updateUser,
    deleteUser,
}