const express = require('express')
const router = express.Router()
const {getUser,
       setUser,
       updateUser,
       deleteUser,} = require('../controllers/userController')


router.route('/').get(getUser).post(setUser)
router.route('/:id').put(updateUser).delete(deleteUser)

/*
CODE ABOVE SAVES SOME LINES OF CODE AND DOES THE SAME THING

router.get('/', getUser)

router.post('/', setUser)

router.put('/:id', updateUser)

router.delete('/:id', deleteUser)
*/


module.exports = router
